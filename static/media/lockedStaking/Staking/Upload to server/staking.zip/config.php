<?php

//setup all variable web bg color , you can change with gradient bg as well
$mainBg = 'background: #08060b;'; //main background color
$headerBg = 'background: #27262c;'; //header background color
$stakeBg = 'background: #19525f;'; //staking background color

//setup title text
$titleWeb = 'Locked Staking';
$webDescription = 'Locked Staking Dapps';
$keywords = 'dapps, token staking, web3, smartcontract, solidity, ERC20, BEP20, ethereum, binance, polygon';
$mainText = 'Locked Staking V1';
$secondText = 'Stake USDT token to earn USDT';
$sitename = 'kevincode';

//favicon logo
$favicons = 'img/token/usdt.png';

//Coin Name
$coinName = 'BNB';//input ETH/BNB/POLYGON/AVAX depend on network

//menu bar link
$menu1 = 'Home';
$menu2 = 'Stake';
$menu3 = 'Buy Token';
$menu4 = 'Chart Token';
$menu5 = 'Explorer';

//menu bar link
$menuLink1 = '#';
$menuLink2 = '#';
$menuLink3 = 'https://pancakeswap.finance/swap?chain=bscTestnet&outputCurrency=0x7ef95a0FEE0Dd31b22626fA2e10Ee6A223F8a684';
$menuLink4 = 'https://www.dextools.io/app/';
$menuLink5 = 'https://testnet.bscscan.com/address/0x7ef95a0FEE0Dd31b22626fA2e10Ee6A223F8a684';

//footer socical media link
$telegram = 'https://t.me/';
$twitter = 'https://twitter.com/';
$github = 'htttps://github.com/';
$facebook = 'https://facebook.com/';