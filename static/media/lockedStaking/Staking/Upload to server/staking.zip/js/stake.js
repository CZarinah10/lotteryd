function copyRef(element) {
  var $temp = $("<input>");
  $("body").append($temp);
  $temp.val($(element).val()).select();
  document.execCommand("copy");
  $temp.remove();
}

$(".copy_ref").click(function(){
    let refv = $(".input_ref").val();
    if(refv !== null){
        copyRef('.input_ref');
		$('#val_err').html("Referral Copied");			
		$.magnificPopup.open({items: {src: '#Error'},type: 'inline'} ); 		
    }
});

function timeConverter(UNIX_timestamp){
    var a = new Date(UNIX_timestamp * 1000);
    var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    var year = a.getFullYear();
    var month = months[a.getMonth()];
    var date = a.getDate();
    var hour = a.getHours();
    var min = a.getMinutes();
    var sec = a.getSeconds();
    var time = date + ' ' + month + ' ' + year + ' ' + hour + ':' + min + ':' + sec ;
    return time;
} 

function toPlainNum(num) {
  return (''+ +num).replace(/(-?)(\d*)\.?(\d*)e([+-]\d+)/,
    function(a,b,c,d,e) {
      return e < 0
        ? b + '0.' + Array(1-e-c.length).join(0) + c + d
        : b + c + d + Array(e-d.length+1).join(0);
    });
}

function secondsToDay(seconds) {
  seconds = Number(seconds);
  var d = Math.floor(seconds / (3600*24));
  var h = Math.floor(seconds % (3600*24) / 3600);
  var m = Math.floor(seconds % 3600 / 60);
  var s = Math.floor(seconds % 60);

  var dDisplay = d > 0 ? d + (d == 1 ? " Day " : " Day ") : "";
  var hDisplay = h > 0 ? h + (h == 1 ? " hour " : " hours ") : "";
  var mDisplay = m > 0 ? m + (m == 1 ? " minute " : " minutes ") : "";
  var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
  return dDisplay + hDisplay + mDisplay + sDisplay;
}

let account;
let web3Modal;
let provider;
let walletConnector;

const params = new URLSearchParams(window.location.search);
const refid = params.get("invite");
var lsRef = localStorage.getItem('referral');

if (!!refid) {
	localStorage.setItem('referral', refid);
	var nodeid = refid;
}else if (lsRef) {
	var nodeid = lsRef;
}

let stakeRow = [
    {
        "id": 0
    },
    {
        "id": 1
    },
    {
        "id": 2
    }
];

$(".btn_logout").hide();			    
$('.account').hide();
$('.usercoin').hide();

var bnbP = localStorage.getItem('bnb');
var tokP = localStorage.getItem('token');

let web4 = new Web3(RPC);
var ctoken2 = new web4.eth.Contract(lesABI, token);
var cstake2 = new web4.eth.Contract(stABI, staking);
let cpair = new web4.eth.Contract(lesABI, LP);
let ctoken;
let cstake;

window.addEventListener('DOMContentLoaded', async (event) => {
    const Web3Modal = window.Web3Modal.default;
    const WalletConnectProvider = window.WalletConnectProvider.default;
    const Authereum = window.Authereum;
    
    const providerOptions = {
        walletconnect: {
            package: WalletConnectProvider,
            options: walletOption
        },
        authereum: {
            package: Authereum // required
        },        
        binancechainwallet: {
            package: true
        },
        opera: {
            package: true
        },
        clvwallet: {
            package: true
        },
        bitkeep: {
            package: true
        },
        starzwallet: {
            package: true
        },
        torus: {
            package: Torus, // required
            options: {
                networkParams: torusOption,
                config: {
                    buildEnv: "production" // optional
                }
            }
        }
    }; 
    web3Modal = new Web3Modal({
        network: 'mainnet',	    
        cacheProvider: false,
        providerOptions,
        disableInjectedProvider: false,
    });
	async function getDec(){
	    try{
            let decimal = await ctoken2.methods.decimals().call();
            let symbol = await ctoken2.methods.symbol().call();	
            return [decimal, symbol];
	    }
	    catch(e){
	        console.log(e);
	    }
	}
	let getTo = await getDec();
    const getLoaded = async () => {
        try {
            if (!!account) {
                $(".btn_connect").hide();
                $(".connect_btn").hide();
                $(".btn_logout").show();
                $('.account').show();
                $('.usercoin').show();

                $('#history0').show();
                $('#history1').show();
                $('#history2').show();
                
                let users = account.substring(0, 12) + '...' + account.substring(36, 42);
                $('.account').html(users);

                const allowance = await ctoken.methods.allowance(account, staking).call();  
                if(allowance == '0'){
                    $(".approve").show();
                    $(".wrap_stake_col").hide();
                }
                else{
                    $(".approve").hide();
                    $(".wrap_stake_col").show();
                }
                
                stakeRow.forEach(async function(r){
                    const earned = await cstake.methods.earnedToken(r.id, account).call();
                    let fearn = earned[0] / (10 ** getTo[0]);
                    let fearn2 = earned[1] / (10 ** getTo[0]);
                    $('#earnVal' + r.id).html(fearn.toFixed(6));
                    let earnedsRate = fearn * tokP;
                    $('#earnsRate' + r.id).html('[$' + earnedsRate.toFixed(2) + ']');
                    
                    const tbalance = await ctoken.methods.balanceOf(account).call(); 
                    let ftbalance = tbalance / (10 ** getTo[0]);
                    $('#tVal' + r.id).html(ftbalance.toFixed(6));
                    
                    let fbalRate = ftbalance * tokP;
                    $('#valBalrate' + r.id).html(fbalRate.toFixed(2));
                     
                    const staked = await cstake.methods.canWithdrawAmount(r.id, account).call(); 
                    let ftstaked = staked[0] / (10 ** getTo[0]);//staked
                    let ftstaked2 = staked[1] / (10 ** getTo[0]); //canwithdraw
                    $('#stakeVal' + r.id).html(ftstaked.toFixed(6));
                    
                    let fstakRate = ftstaked * tokP;
                    $('#valStakrate' + r.id).html(fstakRate.toFixed(2));
                    
                    $('#modalDepositVal' + r.id).html(ftbalance.toFixed(2));
                    $('#modalWithdrawVal' + r.id).html(ftstaked2.toFixed(2));
                    
                    $('#modalTotalClaimVal' + r.id).html(fearn.toFixed(8)); 
                    $('#modalClaimVal' + r.id).html(fearn2.toFixed(8));
                    
                    const stkData = await cstake.methods.stakeData(r.id, account).call();
                    $(".history" + r.id).click(function(){
                        $('.historyStake').html('');
                        stkData.forEach(function(h1){
                            let history_table = `
                                <li class="bgArrayHistory">
                                    <span>Staked Amount : ${h1[0] / (10 ** getTo[0])} ${getTo[1]}</span><br>
                                    <span>Staked At : ${timeConverter(h1[1])}</span><br>
                                    <span>Staked End : ${timeConverter(h1[2])}</span>
                                </li>          
                            `;
                            $('.historyStake').append(history_table);
                            $.magnificPopup.open({items: {src: '#historyModal'},type: 'inline'} ); 
                        });
                    });                     
                });
                const userRef = await cstake.methods.userRef(account).call();
                $(".total_ref").html(userRef.totalRef);
                
                $(".total_earn").html((userRef.totalEarning / (10 ** getTo[0])).toFixed(2) + ' ' +getTo[1]);
                $(".total_claimable").html((userRef.claimableEarning / (10 ** getTo[0])).toFixed(2) + ' ' + getTo[1]);
                $("#claimRefEarning").html((userRef.claimableEarning / (10 ** getTo[0])).toFixed(2));
                
                let fearnRate = (userRef.totalEarning / (10 ** getTo[0])) * tokP;
                let fClamRate = (userRef.claimableEarning / (10 ** getTo[0])) * tokP;
                $("#valEarnsRate").html('[$' + fearnRate.toFixed(2) + ']');
                $("#valClamRate").html('[$' + fClamRate.toFixed(2) + ']');
                
         	    const coinBalance = await web3.eth.getBalance(account);
                const coinWei = web3.utils.fromWei(coinBalance, "ether");
                let userCoin = parseFloat(coinWei).toFixed(6);

                let bnbVal = userCoin * bnbP;
                $('.usercoin').html('BNB Balance: ' + userCoin + ` ($${bnbVal.toFixed(2)})`);
                
                $('.input_ref').val(mainURL + '?invite=' + account);
            }
            else {
                $(".btn_connect").show();
                $(".connect_btn").show();
                $(".btn_logout").hide();			    
                $('.account').hide();
                $('.usercoin').hide();
                $(".wrap_stake_col").hide();
                $('.approve').hide();
                
                $('#stakeVal0').html('0');
                $('#tVal0').html('0');
                $('#earnVal0').html('0');
 
                $('#stakeVal1').html('0');
                $('#tVal1').html('0');
                $('#earnVal1').html('0');
                
                $('#stakeVal2').html('0');
                $('#tVal2').html('0');
                $('#earnVal2').html('0');
                
                $('.input_ref').val(mainURL + '?invite=');
                $('#modalDepositVal').html('-');
                $('#modalWithdrawVal').html('-'); 
                $(".total_ref").html('-');
                $(".total_earn").html('-'); 
                $(".total_claimable").html('-'); 
                
                $("#valEarnsRate").html('-'); 
                $("#valClamRate").html('-'); 

                $("#valBalrate0").html('-'); 
                $("#valStakrate0").html('-'); 
                $("#valBalrate1").html('-'); 
                $("#valStakrate1").html('-'); 
                $("#valBalrate2").html('-'); 
                $("#valStakrate2").html('-');                 
                
                $('#earnsRate0').html('-');
                $('#earnsRate1').html('-');
                $('#earnsRate2').html('-');

                $('#history0').hide();
                $('#history1').hide();
                $('#history2').hide();                
            }
        }
        catch(e){
            const networkId = await web3.eth.getChainId();
            if(networkId !== baseChainId){
                $('#val_err').html("Please change to" + netName);			
                $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );
            }  
            console.log(e);
    	    $('#val_err').html(e.message);			
    	    $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );            
        }
    } 
    const fetchAccountData = async () => {
        web3 = new Web3(provider);
        const accounts = await web3.eth.getAccounts();
        account = accounts[0];
        ctoken = new web3.eth.Contract(lesABI, token);
        cstake = new web3.eth.Contract(stABI, staking);
        getLoaded();
    }
    const onConnect = async () => {
        try {
            provider = await web3Modal.connect();
        } 
        catch(e) {
            console.log(e);
            return;
        }
        provider.on("accountsChanged", (accounts) => {
            fetchAccountData();
        });
        provider.on("chainChanged", (chainId) => {
            window.location.reload();
        });
        return await fetchAccountData();
    }
	if (web3Modal.cachedProvider) {
		onConnect();
	}
    $(document).on('click', '.btn_connect', onConnect);
    $(document).on('click', '.connect_btn', onConnect);
	$(document).on('click', '.btn_logout', async function() {
		if (provider.disconnect) {
			await provider.disconnect();
			await web3Modal.clearCachedProvider();
		}
		provider = null;
		account = null;
		getLoaded();
	});
	async function getLP(){
	    try{
	        const pairs = await cpair.methods.getReserves().call();
            const checkBnb = await cpair.methods.token0().call();
            if(checkBnb === BNB){
                let pair0 = pairs._reserve0;
                let pair1 = pairs._reserve1; 
                let f_pair0 = pair0 / (10 ** 18);
                let f_pair1 = pair1 / (10 ** getTo[0]);
                let ptokenBnb = f_pair0 / f_pair1;
                return [f_pair1, f_pair0, ptokenBnb];
            }
            else{
                let pair0 = pairs._reserve0; //token
                let pair1 = pairs._reserve1; //bnb
                let f_pair0 = pair0 / (10 ** getTo[0]);
                let f_pair1 = pair1 / (10 ** 18);
                let ptokenBnb = f_pair1 / f_pair0;  
                return [f_pair0, f_pair1, ptokenBnb];
            }	        
	    }
	    catch(e){
	        console.log(e);
	    }	    
	}
	let getToLp = await getLP();
	
	async function dataLoad(){
	    try{
            const totLp = await cpair.methods.totalSupply().call();
            let ftotLp = totLp / (10 ** 18);
            
            const plan0 = await cstake2.methods.plans(0).call();
            const plan1 = await cstake2.methods.plans(1).call();
            const plan2 = await cstake2.methods.plans(2).call();
            
            let fts0 = plan0.overallStaked / (10 ** getTo[0]); 
            let fts1 = plan1.overallStaked / (10 ** getTo[0]); 
            let fts2 = plan2.overallStaked / (10 ** getTo[0]); 
            
            let mergeScount = Number(plan0.stakesCount) + Number(plan1.stakesCount) + Number(plan2.stakesCount);
            let mergeStake = fts0 + fts1 + fts2;
            
            let fmergec = new Intl.NumberFormat().format(mergeScount);
            let fmerges = new Intl.NumberFormat().format(mergeStake);
            $('#totalStake').html(fmerges + ' ' +getTo[1]);
            $('#totalCount').html(fmergec);
            
            $('#aprs0').html(plan0.apr + "%");
            $('#aprs1').html(plan1.apr + "%");
            $('#aprs2').html(plan2.apr + "%");

            $('#c_p1').html(plan0.apr + '%');
            $('#c_p2').html(plan1.apr + '%');
            $('#c_p3').html(plan2.apr + '%');
            
            let resultAPR1 = (plan0.apr / 100) * 1000;
            let resultAPR2 = (plan1.apr / 100) * 1000;
            let resultAPR3 = (plan2.apr / 100) * 1000;
            
            $('#c_r1').html('$' + resultAPR1);
            $('#c_r2').html('$' + resultAPR2);
            $('#c_r3').html('$' + resultAPR3);
            
            $('#penalty0').html(plan0.earlyPenalty);
            $('#penalty1').html(plan1.earlyPenalty);
            $('#penalty2').html(plan2.earlyPenalty);
            
            $('.ddepoFee0').html(plan0.depositDeduction + '%');
            $('.ddepoFee1').html(plan1.depositDeduction + '%');
            $('.ddepoFee2').html(plan2.depositDeduction + '%');

            $('.dwithFee0').html(plan0.withdrawDeduction + '%');
            $('.dwithFee1').html(plan1.withdrawDeduction + '%');
            $('.dwithFee2').html(plan2.withdrawDeduction + '%');

            $('.dtotalStaked0').html(fts0);
            $('.dtotalStaked1').html(fts1);
            $('.dtotalStaked2').html(fts2);

            $('#duration0').html(secondsToDay(plan0.stakeDuration));
            $('#duration1').html(secondsToDay(plan1.stakeDuration));
            $('#duration2').html(secondsToDay(plan2.stakeDuration));

            $('.timeframe0').html(secondsToDay(plan0.stakeDuration));
            $('.timeframe1').html(secondsToDay(plan1.stakeDuration));
            $('.timeframe2').html(secondsToDay(plan2.stakeDuration));
            
            $('#tokenName').html(getTo[1]);
            $.getJSON(coingeckoAPI, function(data) {
                let bnb_price = data[cids].usd;
                
                const l_bnb = getToLp[1] * bnb_price; 
                const t_pri = getToLp[2] * bnb_price;//token price on usd
                const l_tok = getToLp[0] * t_pri;
                
                const liquid_all = l_bnb + l_tok;//total liquid
                const lpBnbPrice = liquid_all / ftotLp;//LP price	
                
                let tvls = mergeStake * t_pri;
                let ftvl = new Intl.NumberFormat().format(tvls.toFixed(2));
                let formatLiquid = new Intl.NumberFormat().format(liquid_all.toFixed(2));
                
                $('#liquid').html('$' + formatLiquid);
                $('#bnbPrice').html('$' + bnb_price);
                $('#tokenPrice').html('$' + t_pri.toFixed(6));
                $('#tvls').html('$' + ftvl);
                
                localStorage.setItem('bnb', bnb_price);
                localStorage.setItem('token', t_pri);
            });
	    }
	    catch(e){
	        console.log(e);
	    }
	}
	dataLoad();
	setInterval(() => dataLoad(), 60000);

    stakeRow.forEach(function(row){
        let modalPop = `
            <div id="deposit_modal${row.id}" class="zoom-anim-dialog mfp-hide modal textBlack">
            	<button class="modal__close" type="button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M13.41,12l4.3-4.29a1,1,0,1,0-1.42-1.42L12,10.59,7.71,6.29A1,1,0,0,0,6.29,7.71L10.59,12l-4.3,4.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l4.29,4.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z"></path></svg></button>
            	
            	<h3>Deposit Token</h3>
            	<small>Available Balance : <b id="modalDepositVal${row.id}">0</b></small>
            	<input type="number" min="0" step="0.00001" class="input_val deposit_val${row.id}" placeholder="0.00">
            	<span class="base_btn txDeposit${row.id}">Deposit</span>
            </div>
            
            <div id="withdraw_modal${row.id}" class="zoom-anim-dialog mfp-hide modal textBlack">
            	<button class="modal__close" type="button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M13.41,12l4.3-4.29a1,1,0,1,0-1.42-1.42L12,10.59,7.71,6.29A1,1,0,0,0,6.29,7.71L10.59,12l-4.3,4.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l4.29,4.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z"></path></svg></button>
            	
            	<h3>Withdraw Token</h3>
            	<small>Staked Balance : <b id="modalWithdrawVal${row.id}">0</b></small>
            	<input type="number" min="0" step="0.00001" class="input_val withdraw_val${row.id}" placeholder="0.00">
            	<small>Early Withdraw Penalty <b id="penalty${row.id}"></b>%</small>
            	<span class="base_btn txWithdraw${row.id}">Withdraw</span>
            </div>
            
            <div id="claim_modal${row.id}" class="zoom-anim-dialog mfp-hide modal textBlack">
            	<button class="modal__close" type="button"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M13.41,12l4.3-4.29a1,1,0,1,0-1.42-1.42L12,10.59,7.71,6.29A1,1,0,0,0,6.29,7.71L10.59,12l-4.3,4.29a1,1,0,0,0,0,1.42,1,1,0,0,0,1.42,0L12,13.41l4.29,4.3a1,1,0,0,0,1.42,0,1,1,0,0,0,0-1.42Z"></path></svg></button>
            	
            	<h3>Claim ${getTo[1]}</h3>
            	<small>Total Earned : <b id="modalTotalClaimVal${row.id}">0</b></small>
            	<small>Available to claim : <b id="modalClaimVal${row.id}">0</b></small>

            	<small>if no available to claim it's mean still locked</small>
            	<span class="base_btn txClaim${row.id}">Claim</span>
            </div>            
        `;
        $('#modalPop').append(modalPop);
        
        let injects = `
            <div class="col-lg-4 col-md-6">
                <div class="farms-single-section gradient-border stakeBg">
                    <div class="coin-desc">
                        <div class="coin-desc-left">
                            <img src="img/token/usdt.png" alt="">
                        </div>
                        <div class="coin-desc-right newFont">
                            <h4>${getTo[1]} <b id="duration${row.id}"></b></h4>
                            <ul>
                                <li class="bd"><i class="fas fa-lock"></i> Locked</li>
                                <li class="bg history${row.id} nonSelect">Stake History</li>
                            </ul>
                        </div>
                    </div>
                    <div class="calculat">
                        <div class="calculat-left">
                            <h6>APR :</h6>
                            <h6>Earn :</h6>
                            <p>${getTo[1]} Earned</p>
                        </div>
                        <div class="calculat-right">
                            <h6><i id="cal${row.id}" class="fas fa-calculator"></i><b class="newFont aprNum" id="aprs${row.id}"></b></h6>
                            <h6>${getTo[1]}</h6>
                        </div>
                    </div>
            		<div class="wrap_stake_col">
                        <div class="harvest">
                        	<h2 id="earnVal${row.id}">0</h2>
                        	<span id="claim${row.id}">Claim</span>
                        </div>
                        <small>${getTo[1]} Available [$<b id="valBalrate${row.id}"></b>]</small>
                        <div class="harvest">
                        	<h2 id="tVal${row.id}">0</h2>
                        	<span id="deposit${row.id}">Deposit</span>
                        </div>
                        <small>${getTo[1]} Staked [$<b id="valStakrate${row.id}"></b>]</small>
                        <div class="harvest">
                        	<h2 id="stakeVal${row.id}">0</h2>
                        	<span id="withdraw${row.id}">Withdraw</span>
                        </div>										    
                    </div>                    
                    <div class="unlocks">
                        <a class="connect_btn">Unlock Wallet</a>
                        <a class="connect_btn approve">Approve Contract</a>
                    </div>
                    <div class="farm-desc">
                        <a id="detail${row.id}" class="collapsible">Details
                            <svg viewBox="0 0 24 24" color="text" width="20px" xmlns="http://www.w3.org/2000/svg" style="fill: #fff;">
                            <path d="M8.11997 9.29006L12 13.1701L15.88 9.29006C16.27 8.90006 16.9 8.90006 17.29 9.29006C17.68 9.68006 17.68 10.3101 17.29 10.7001L12.7 15.2901C12.31 15.6801 11.68 15.6801 11.29 15.2901L6.69997 10.7001C6.30997 10.3101 6.30997 9.68006 6.69997 9.29006C7.08997 8.91006 7.72997 8.90006 8.11997 9.29006Z">
                            </path>
                            </svg>                        
                        </a>
                        <div class="detailed">
                            <div class="spaceBetween">
                                <div class="attr_text">Total Staked :</div>
                                <div class="attr_text dtotalStaked${row.id}">0</div>
                            </div>
                            <div class="spaceBetween">
                                <div class="attr_text">Deposit Fee :</div>
                                <div class="attr_text ddepoFee${row.id}">0%</div>
                            </div>
                            <div class="spaceBetween">
                                <div class="attr_text">Withdraw Fee:</div>
                                <div class="attr_text dwithFee${row.id}">0%</div>
                            </div>
                            <div class="spaceBetween">
                            <a class="btnDetail" href="${swapLink}" target="_blank">Get ${getTo[1]}
                                <svg viewBox="0 0 24 24" color="primary" width="20px" xmlns="http://www.w3.org/2000/svg" style="fill: #fff;">
                                <path d="M18 19H6C5.45 19 5 18.55 5 18V6C5 5.45 5.45 5 6 5H11C11.55 5 12 4.55 12 4C12 3.45 11.55 3 11 3H5C3.89 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V13C21 12.45 20.55 12 20 12C19.45 12 19 12.45 19 13V18C19 18.55 18.55 19 18 19ZM14 4C14 4.55 14.45 5 15 5H17.59L8.46 14.13C8.07 14.52 8.07 15.15 8.46 15.54C8.85 15.93 9.48 15.93 9.87 15.54L19 6.41V9C19 9.55 19.45 10 20 10C20.55 10 21 9.55 21 9V4C21 3.45 20.55 3 20 3H15C14.45 3 14 3.45 14 4Z">
                                </path>
                                </svg>                            
                            </a>
                            <a class="btnDetail" href="${stakeContract}" target="_blank">View Contract
                                <svg viewBox="0 0 24 24" color="primary" width="20px" xmlns="http://www.w3.org/2000/svg" style="fill: #fff;">
                                <path d="M18 19H6C5.45 19 5 18.55 5 18V6C5 5.45 5.45 5 6 5H11C11.55 5 12 4.55 12 4C12 3.45 11.55 3 11 3H5C3.89 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V13C21 12.45 20.55 12 20 12C19.45 12 19 12.45 19 13V18C19 18.55 18.55 19 18 19ZM14 4C14 4.55 14.45 5 15 5H17.59L8.46 14.13C8.07 14.52 8.07 15.15 8.46 15.54C8.85 15.93 9.48 15.93 9.87 15.54L19 6.41V9C19 9.55 19.45 10 20 10C20.55 10 21 9.55 21 9V4C21 3.45 20.55 3 20 3H15C14.45 3 14 3.45 14 4Z">
                                </path>
                                </svg>                            
                            </a>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
        `;
        $('#root').append(injects);
        
        $("#deposit" + row.id).click(function(){
        	$.magnificPopup.open({items: {src: '#deposit_modal' + row.id},type: 'inline'} );
        });
        
        $("#withdraw" + row.id).click(function(){
        	$.magnificPopup.open({items: {src: '#withdraw_modal' + row.id},type: 'inline'} );
        });   

        $("#claim" + row.id).click(function(){
        	$.magnificPopup.open({items: {src: '#claim_modal' + row.id},type: 'inline'} );
        });
        
        $(".detail").click(function(){
        	$.magnificPopup.open({items: {src: '#Detail'},type: 'inline'} );
        });   
        
        $("#cal" + row.id).click(function(){
            $.magnificPopup.open({items: {src: '#cal_modal'},type: 'inline'} );  
        }); 

        $("#modalDepositVal" + row.id).click(function(){
            let depoVals = Number($("#modalDepositVal" + row.id).text());  
            $(".deposit_val" + row.id).val(Math.floor(depoVals));
        });

        $("#modalWithdrawVal" + row.id).click(function(){
            let withVals = Number($("#modalWithdrawVal" + row.id).text());  
            $(".withdraw_val" + row.id).val(Math.floor(withVals));
        });
        
        $('.modal__close').on('click', function (e) {
        	e.preventDefault();
        	$.magnificPopup.close();
        });
        
        $('#detail' + row.id).on('click', function (e) {
            this.classList.toggle("active");
            var content = this.nextElementSibling;
            if (content.style.display === "block") {
              content.style.display = "none";
            }
            else {
              content.style.display = "block";
            }
        });
        
        $(".wrap_stake_col").hide();
        
        $( ".txDeposit" + row.id).click(async function() {
            if(account){
                try{
        			const haveToken = await ctoken.methods.balanceOf(account).call();    
              	    let StakeAmount = Number($('.deposit_val' + row.id).val());
              	    let hexAmount = web3.utils.toHex(toPlainNum(StakeAmount * (10 ** getTo[0]))); 
              	    if(haveToken > 0 && StakeAmount > 0 && haveToken >= StakeAmount){
                        await cstake.methods.referralStake(row.id, hexAmount, nodeid).send({
                            from: account,
                        })
                        .on("transactionHash", function(hash) {
                            console.log(hash);
                            $('#val_err').html("Transaction submited to network <br>" + `<a href='${explorer}/tx/${hash}' target='_blank'>Check on Explorer</a>`);			
                            $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} ); 	                
                        })
                        .then(function(receipt){
                            fetchAccountData();
                            $('#val_err').html("Transaction confirmed");			
                            $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                     
                        });
              	    }
              	    else{
                        $('#val_err').html("balance not enough");			
                        $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );         	        
              	    }
                }
                catch(e){
                    $('#val_err').html(e.message);			
                    $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );
                }
            }
            else{
                $('#val_err').html("Wallet not connected");			
                $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );           
            }
        });    
    
        $(".txWithdraw" + row.id).click(async function() {
            if(account){
                try{
              	    let StakedAmount = Number($('.withdraw_val' + row.id).val());
              	    let hexAmount2 = web3.utils.toHex(toPlainNum(StakedAmount * (10 ** getTo[0])));                 
                    await cstake.methods.unstake(row.id, hexAmount2).send({
                        from: account,
                    })
                    .on("transactionHash", function(hash) {
                        console.log(hash);
                        $('#val_err').html("Transaction submited to network <br>" + `<a href='${explorer}/tx/${hash}' target='_blank'>Check on Explorer</a>`);			
                        $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} ); 	                
                    })
                    .then(function(receipt){
                        fetchAccountData();
                        $('#val_err').html("Transaction confirmed");			
                        $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                     
                    }); 
                }
                catch(e){
                    $('#val_err').html(e.message);			
                    $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );
                }
            }
            else{
                $('#val_err').html("Wallet not connected");			
                $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );           
            }
        });
    
        $( ".txClaim" + row.id).click(async function() {
            if(account){
                try{
                    const earned = await cstake.methods.earnedToken(row.id, account).call();
                    let earn = earned[1] / (10 ** getTo[0]);
                    if(earn > 0){
                        await cstake.methods.claimEarned(row.id).send({
                            from: account,
                        })
                        .on("transactionHash", function(hash) {
                            console.log(hash);
                            $('#val_err').html("Transaction submited to network <br>" + `<a href='${explorer}/tx/${hash}' target='_blank'>Check on Explorer</a>`);			
                            $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} ); 	                
                        })
                        .then(function(receipt){
                            fetchAccountData();
                            $('#val_err').html("Tx confirmed");			
                            $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                     
                        }); 
                    }
                    else{
                        $('#val_err').html("still locked / no amount available to claim");			
                        $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                    
                    }
                }
                catch(e){
                    $('#val_err').html(e.message);			
                    $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );
                }
            }
            else{
                $('#val_err').html("Wallet not connected");			
                $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );           
            }
        });
        
        $('.approve').hide();
    });

    $(".approve").click(async function() {
        if(account){
            try{
                await ctoken.methods.approve(staking, "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff").send({
                    from: account,
                })
                .on("transactionHash", function(hash) {
                    console.log(hash);
                    $('#val_err').html("Transaction submited to network <br>" + `<a href='${explorer}/tx/${hash}' target='_blank'>Check on Explorer</a>`);			
                    $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} ); 	                
                })
                .then(function(receipt){
                    fetchAccountData();
                    $('#val_err').html("Transaction confirmed");			
                    $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                     
                }); 
            }
            catch(e){
             	$('#val_err').html(e.message);			
                $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );
            }
        }
        else{
     		$('#val_err').html("wallet not connected");			
            $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );           
        }
    });

    $(".claimEarning").click(function(){
    	$.magnificPopup.open({items: {src: '#claimRefModal'},type: 'inline'} );
    }); 

    $("#claimRefEarning").click(function(){
        let claimEarnVals = Number($("#claimRefEarning").text());  
        $(".refClaim_val").val(claimEarnVals.toFixed(0));
    });
    
    $(".txRefClaim").click(async function() {
        if(account){
            try{
          	    let ClaimAmount = Number($('.refClaim_val').val());
          	    let hexClaims = web3.utils.toHex(toPlainNum(ClaimAmount * (10 ** getTo[0])));                 
                const refEarns = await cstake.methods.userRef(account).call();
                let frefEarn = refEarns.claimableEarning / (10 ** getTo[0]);
                
                if(Number(frefEarn) > 0 && Number(frefEarn) >= ClaimAmount){
                    await cstake.methods.claimReferralEarnings(hexClaims).send({
                        from: account,
                    })
                    .on("transactionHash", function(hash) {
    	                console.log(hash);
         		        $('#val_err').html("Transaction submited to network <br>" + `<a href='${explorer}/tx/${hash}' target='_blank'>Check on Explorer</a>`);			
        		        $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} ); 	                
                    })
                    .then(function(receipt){
                        fetchAccountData();
         		        $('#val_err').html("Transaction confirmed");			
        		        $.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                     
                    });                     
                }
                else{
             		$('#val_err').html("Claimable balance not available");			
            		$.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                    
                }
            }
            catch(e){
                console.log(e);
             	$('#val_err').html(e.message);			
            	$.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );                
            }
        }
        else{
     		$('#val_err').html("wallet not connected");			
    		$.magnificPopup.open({items: {src: '#Error'},type: 'inline'} );           
        }
    });
    
    if(window.ethereum){
        const getChain = await ethereum.request({ method: 'net_version' });
        if (getChain !== baseChainId) {
            try {
              await ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: param1,
              });
            } 
            catch (switchError) {
              if (switchError.code === 4902) {
                try {
                  await ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: param2,				
                  });
                } 
                catch (addError) {
                    console.log(addError);
                }
              }
            }
        }        
    }
});