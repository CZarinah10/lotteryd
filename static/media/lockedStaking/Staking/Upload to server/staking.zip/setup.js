//GLOBAL VARIABLE
var mainURL = "https://stake.kevincode.id";
var token = "0x7ef95a0FEE0Dd31b22626fA2e10Ee6A223F8a684"; //this token contract address
var staking = "0xCcdA8818A1AA18B2C818628Ca4C179ca996181D0";//this staking contract address
var LP = "0xF855E52ecc8b3b795Ac289f85F6Fd7A99883492b";// WBNB/YOURTOKEN LP pair contract address (Router V2)

//0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd = wbnb testnet (BSCTEST)
//0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c = wbnb mainnet (BSC)
var BNB = "0xae13d989daC2f0dEbFf460aC112a837C89BAa7cd"; //WRAPPED BNB CONTRACT ADDRESS

//get other RPC network here => https://www.ankr.com/rpc/
//https://rpc.ankr.com/bsc
//https://rpc.ankr.com/bsc_testnet_chapel
var RPC = "https://rpc.ankr.com/bsc_testnet_chapel";
var explorer = 'https://testnet.bscscan.com';
var baseChainId = 97;
var netName = "Binance Smartchain";

//param add network
//0x61 = BSC TESTNET , 0x38 = BSCMAINNET
//0x13881 = polygon mumbai , 0x89 = polygon mainnet
//0xA86A = avax mainnet
var param1 = [{ chainId: '0x61' }];
var param2 = [
    {
        chainId: '0x61',
        chainName: 'BNB',
        nativeCurrency: {
            name: 'BNB',
            symbol: 'tBNB',
            decimals: 18
        },					
        rpcUrls: [RPC],
        blockExplorerUrls: [explorer],
    },
];

//config for walletconnect
var walletOption = {
    network: "binance",
    rpc: {56:'https://rpc.ankr.com/bsc'},
    chainId: 56
};
var torusOption = {
    host: "https://rpc.ankr.com/bsc", 
    chainId: 56, 
    networkId: 56
};

//config for coingecko API
var cids = 'binancecoin'; //this is API id, you can find this on coin info coingecko
var coingeckoAPI = `https://api.coingecko.com/api/v3/simple/price?ids=${cids}&vs_currencies=usd`;

//detail link
var swapLink = `http://pancake.kiemtienonline360.com/#/swap?outputCurrency=${token}`;
var stakeContract = `${explorer}/address/${staking}`;